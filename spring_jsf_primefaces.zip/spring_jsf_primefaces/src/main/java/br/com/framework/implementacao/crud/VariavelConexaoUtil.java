package br.com.framework.implementacao.crud;


/**
 * Nome do caminho do JNDI datasource Tomcat
 * @author thiersbarizon
 *
 */
public class VariavelConexaoUtil {
	
	public static String JAVA_COMP_ENV_JDBC_DATA_SOURCE = "java:/comp/env/jdbc/datasource";

}
